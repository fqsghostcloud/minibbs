package main

import (
	"fmt"
	"time"
)

func main() {
	for {
		fmt.Println("ddddddddddddddddd")
		time.Sleep(3 * time.Second)
	}
}         